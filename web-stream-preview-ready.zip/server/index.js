import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { WebSocketServer } from 'ws';
const port=Number(process.env.PORT||8787);
const http=createServer((req,res)=>{res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({ok:true,service:'web-stream-signaling'}));});
const wss=new WebSocketServer({noServer:true});const rooms=new Map();const clients=new Map();
http.on('upgrade',(req,socket,head)=>{if(req.url!=='/ws'){socket.destroy();return;}wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));});
const send=(ws,msg)=>{if(ws.readyState===1)ws.send(JSON.stringify(msg));};
function remove(ws){const c=clients.get(ws);if(!c)return;const members=rooms.get(c.room);members?.delete(c.id);for(const p of members?.values()||[])send(p.ws,{type:'peer-left',id:c.id});if(!members?.size)rooms.delete(c.room);clients.delete(ws);}
wss.on('connection',ws=>{ws.on('message',raw=>{let m;try{m=JSON.parse(raw.toString());}catch{return send(ws,{type:'error',message:'Invalid message'});}
 if(m.type==='join'){if(clients.has(ws))return;const room=String(m.room||'').trim().toUpperCase().replace(/[^A-Z0-9-]/g,'').slice(0,12);const role=m.role==='watch'?'watch':'broadcast';if(!room)return send(ws,{type:'error',message:'A room code is required'});if(!rooms.has(room))rooms.set(room,new Map());const members=rooms.get(room);if(role==='broadcast'&&[...members.values()].some(p=>p.role==='broadcast')){send(ws,{type:'error',message:'This room already has a host'});ws.close();return;}const id=randomUUID();const existing=[...members.values()].map(p=>({id:p.id,role:p.role}));members.set(id,{id,room,role,ws});clients.set(ws,{id,room,role,ws});send(ws,{type:'joined',id,room,peers:existing});for(const p of members.values())if(p.id!==id)send(p.ws,{type:'peer-joined',id,role});return;}
 const c=clients.get(ws);if(!c)return send(ws,{type:'error',message:'Join a room first'});if(['offer','answer','ice-candidate'].includes(m.type)){const target=[...(rooms.get(c.room)?.values()||[])].find(p=>p.id===m.to);if(target)send(target.ws,{...m,from:c.id});return;}if(m.type==='stream-ended')for(const p of rooms.get(c.room)?.values()||[])if(p.id!==c.id)send(p.ws,{type:'stream-ended',from:c.id});
 });ws.on('close',()=>remove(ws));ws.on('error',()=>remove(ws));});
http.listen(port,'0.0.0.0',()=>console.log(`Web Stream signaling server listening on :${port}`));
