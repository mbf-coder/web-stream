# Web Stream

A browser-first live studio concept built with React, TypeScript, Vite, WebRTC, and WebSocket signaling. The UI is responsive for desktop, tablet, and mobile browsers.

## Included in this MVP

- Responsive host/viewer studio and local camera/microphone controls.
- Room codes and WebRTC peer-to-peer audio/video for small test sessions.
- WebSocket signaling server with room membership and SDP/ICE relay.
- Distribution settings UI for Facebook Live, YouTube Live, Twitch, TikTok/Kick and custom RTMP/RTMPS destinations.
- GitHub Actions workflow to build and publish a static preview on GitHub Pages.
- Security and integration guidance in [`docs/PLATFORM-INTEGRATIONS.md`](docs/PLATFORM-INTEGRATIONS.md).

## Important integration status

**The platform cards and custom RTMP form are UI scaffolding, not connected integrations yet.** They do not authenticate platform accounts, save stream keys, or send a broadcast to external social networks. OAuth requires provider app credentials, callback URLs, scopes, token storage, and sometimes app review. RTMP publishing requires a server-side media relay/FFmpeg pipeline; a browser cannot publish RTMP directly. Do not enter real production stream keys into this prototype.

## Run locally

Requires Node.js 20+.

```bash
npm install
npm run dev
```

In another terminal:

```bash
npm run dev:server
```

Open the Vite URL (usually `http://localhost:5173`). To test from another device, use a reachable host address and make sure the signaling port is reachable. Camera/microphone access requires HTTPS in deployed environments; localhost is allowed during local development.

## Configuration

Copy `.env.example` to `.env` for local configuration:

- `VITE_SIGNALING_URL`: optional WebSocket URL, such as `wss://your-domain.example/ws`.
- `PORT`: signaling server port (default `8787`).

Do not put OAuth client secrets, access tokens, or long-lived stream keys in `VITE_*` variables or commit them to Git.

## Build and preview

```bash
npm run build
npm run preview
```

The GitHub Actions workflow in `.github/workflows/deploy-preview.yml` builds the frontend and deploys `dist/` to GitHub Pages on pushes to `main`. After the workflow succeeds and Pages is enabled, the preview URL should be:

**https://mbf-coder.github.io/web-stream/**

GitHub Pages hosts the static UI only. It does not host the WebSocket server, OAuth callbacks, or RTMP media pipeline. Those need a separate backend deployment.

## Production architecture

For a real multistream product, use browser capture → WebRTC/WHIP ingest → trusted media gateway → server-side RTMP/RTMPS outputs. Use backend OAuth Authorization Code flows with state/PKCE as supported, encrypted token storage, authorization, rate limiting, secret redaction, and disconnect/revocation support. Peer-to-peer mesh broadcasting is only for small audiences; use an SFU or managed media service at scale.

## License

MIT. See [`LICENSE`](LICENSE).
