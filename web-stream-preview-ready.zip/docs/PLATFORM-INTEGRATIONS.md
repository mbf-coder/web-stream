# Platform integrations: secure implementation plan

## What works in this MVP

The studio includes an interface for selecting the distribution path and entering a custom RTMP destination. The platform cards are intentionally marked as requiring setup: OAuth buttons are explanatory placeholders, and the RTMP form does not persist or transmit credentials. No platform account is connected by this UI alone.

## Recommended architecture

A browser cannot publish RTMP directly. Capture media in the browser, send it to a trusted media gateway using WebRTC/WHIP, then use a server-side media pipeline (for example, FFmpeg managed by a backend or a media server with RTMP output) to fan out to each configured RTMP/RTMPS ingest destination. Keep the media gateway and egress workers separate from the public static frontend.

For production, prefer a managed multistream provider or a maintained media server rather than building a transcoding pipeline from scratch. Limit concurrent outputs and verify platform ingest requirements, codec, bitrate, keyframe interval, and account eligibility.

## OAuth flow

Use Authorization Code flow on the server, preferably with PKCE where supported. Register an app separately with Meta, Google/YouTube, Twitch, and any other provider. Store client secrets in deployment environment variables or a secrets manager. The browser should navigate to a backend `/auth/:provider/start` endpoint; the backend creates a state/PKCE challenge, redirects to the provider, validates the callback state, exchanges the code server-side, and stores refresh/access tokens encrypted at rest. Request only the scopes needed, implement disconnect/revocation and token refresh, and never ship client secrets or long-lived tokens in `VITE_*` variables.

OAuth is provider-specific. Facebook Live availability and permissions depend on Meta app review and the Page/user permissions available to the account. YouTube requires Google OAuth consent and the YouTube Data API. Twitch requires a registered Twitch application and the appropriate scopes. TikTok Live access depends on product approval and account eligibility; otherwise use a platform-issued RTMP ingest URL/key where available.

## Custom RTMP/RTMPS destinations

- Collect the ingest URL and stream key through an authenticated backend form.
- Validate the URL against allowed schemes (`rtmp://` or `rtmps://`) and block private/internal IP ranges to mitigate SSRF.
- Never log stream keys; redact secrets from errors and telemetry.
- Encrypt destination credentials at rest; restrict access per user/team and support rotation/deletion.
- Use a server-side job to start/stop FFmpeg or the media server output. Do not run FFmpeg from the browser.
- Apply authorization, rate limits, per-user output quotas, job timeouts, and cleanup on disconnect.

## Preview versus production

The GitHub Pages workflow deploys only the static frontend preview. GitHub Pages cannot run the Node signaling server, OAuth callback server, or media relay. For end-to-end streaming, deploy the backend and media gateway separately over HTTPS/WSS and set `VITE_SIGNALING_URL` at build time. Never place provider secrets in GitHub Pages build variables prefixed with `VITE_`.
